Permission sync fix
===================

Canonical permission value:
- NONE
- NOTICE
- DOCUMENT
- NOTICE,DOCUMENT

Backward compatibility:
- BOTH => NOTICE,DOCUMENT
- ALL  => NOTICE,DOCUMENT for Notice/Document permissions

Approval logic:
- Notice approval is controlled by approvePermission only.
- Admin role alone does not bypass approvePermission.

Booking logic:
- NONE
- BOOKING

Frontend:
- Add/Edit user permission fields are checkbox-based.
- NoticeApprovalPage supports NOTICE,DOCUMENT and does not trust old cached canApproveNotice from localStorage.

After replacing files:
1. Restart BE.
2. Clear localStorage or logout/login again.
3. Re-open Notice Approval and click Refresh.
